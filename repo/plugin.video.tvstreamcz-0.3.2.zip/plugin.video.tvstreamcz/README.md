# TVStreamCZ

Doplněk pro **Kodi** na filmy a seriály. Funguje **zdarma**, bez registrace a bez placeného účtu — stačí Kodi a internet.

## Co umí

- Filmy a seriály v přehledných kategoriích (populární, žánry, roky, novinky)
- Vyhledávání podle názvu
- U seriálů: výběr série → epizody → teprve pak stream
- Plakáty, popisy a roky z metadat (volitelný TMDB klíč jen pro lepší náhledy)
- Historie přehrávání a **Pokračovat ve sledování**
- Filtrování kvality, dabingu a titulků u streamů

## Instalace z repozitáře (doporučeno)

V Kodi přidáte **zdroj** (URL složky `repo/` na GitHubu) a pak nainstalujete **repozitář** – v menu *Instalovat z repozitáře* se objeví **TVStreamCZ Repository** s doplňky.

### 1. Povolit neznámé zdroje

*Nastavení → Doplňky → Neznámé zdroje* → zapnout.

### 2. Přidat zdroj repozitáře

*Nastavení → Správce souborů → Přidat zdroj*

| Pole | Hodnota |
|------|---------|
| Protokol | **HTTPS** (nebo „Protokol internetové sítě“) |
| Adresa serveru | `https://raw.githubusercontent.com/daker52/TVstreamCZ/main/repo/` |
| Uživatelské jméno | *(prázdné)* |
| Heslo | *(prázdné)* |
| Název zdroje | `TVStreamCZ` |

Potvrďte **OK**.

### 3. Nainstalovat repozitář (ZIP ze zdroje)

1. *Doplňky* → ikona **otevřené krabice** (*Instalovat ze souboru*)
2. *Procházet* → zvolte zdroj **TVStreamCZ**
3. Vyberte **`repository.tvstreamcz-1.0.1.zip`**
4. Počkejte na hlášení „Doplněk povolen“

### 4. Instalovat doplňky z repozitáře

*Doplňky → Instalovat z repozitáře → TVStreamCZ Repository*

- **Video doplňky** → TVStreamCZ (`plugin.video.tvstreamcz`)
- **Služby / Titulky** → YTS-Subs CZ (pokud je v repozitáři)

Aktualizace: *Doplňky → Moje doplňky* → kontextové menu → *Zkontrolovat aktualizace*.

### Vlastní URL repozitáře

Sestavení lokálně (před nahráním na server):

```bash
python build_repo.py
python build_repo.py --base-url https://vas-server.cz/kodi-repo/
```

Obsah složky `repo/` nahrajte na web tak, aby `addons.xml` byl dostupný na zadané URL.

---

## Ruční instalace (bez repozitáře)

1. Stáhněte nebo naklonujte repozitář.
2. Složku `plugin.video.tvstreamcz` zkopírujte do složky doplňků Kodi:
   - **Windows:** `%APPDATA%\Kodi\addons\`
   - **Linux:** `~/.kodi/addons/`
   - **Android TV / LibreELEC:** odpovídající `addons` adresář
3. V Kodi: *Nastavení → Doplňky → „Neznámé zdroje“* (pokud instalujete ručně).
4. Restart Kodi nebo *Aktualizovat seznam doplňků*.
5. Otevřete *Doplňky → Video doplňky → TVStreamCZ*.

### Závislosti

- Kodi 20 nebo novější (Python 3)
- Doplněk `script.module.requests` (většinou už v Kodi)

## První spuštění

Po instalaci stačí otevřít doplněk — **nepotřebujete přihlášení ani API klíče**.

Volitelně v nastavení můžete doplnit TMDB API klíč pro bohatší plakáty a přesnější názvy (není povinný).

## Doporučené titulky

K českým titulkům použijte doplněk **[YTS-Subs CZ](https://github.com/daker52/YTS-Subs-CZ)** — automatické vyhledání a zapnutí CZ titulků při startu filmu.

## Licence

GPL-2.0-or-later

# -*- coding: utf-8 -*-
"""Background service – auto attach Czech subtitles when video starts."""
import time

import xbmc

from resources.lib.auto_attach import AutoSubtitleWorker, YtsPlaybackMonitor
from resources.lib.playback_info import log

if __name__ == "__main__":
    log("Auto subtitle service started", xbmc.LOGINFO)
    monitor = YtsPlaybackMonitor()
    while not monitor.waitForAbort(0.5):
        if monitor._pending:
            monitor._pending = False
            time.sleep(2.0)
            if not monitor.abortRequested():
                AutoSubtitleWorker.run()
    log("Auto subtitle service stopped", xbmc.LOGINFO)

# -*- coding: utf-8 -*-
"""Automatic Czech subtitle search and attach on playback start."""
from __future__ import annotations

import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from .playback_info import get_playing_info, log, notify
from .resolve import resolve_imdb_and_subs
from .yts_subs import YtsSubsClient, YtsSubtitle

__addon__ = xbmcaddon.Addon()


def _auto_enabled() -> bool:
    try:
        return __addon__.getSettingBool("auto_subtitles")
    except (AttributeError, RuntimeError):
        return __addon__.getSetting("auto_subtitles") == "true"


def _pick_best_subtitle(subs: list[YtsSubtitle]) -> YtsSubtitle | None:
    if not subs:
        return None
    return max(subs, key=lambda s: (s.rating, s.release_name))


def _apply_subtitle(local_path: str) -> bool:
    """Load .srt into the active player."""
    if not local_path or not os.path.isfile(local_path):
        return False

    path = xbmcvfs.translatePath(local_path)
    player = xbmc.Player()

    for method_name in ("setSubtitles", "addSubtitle"):
        method = getattr(player, method_name, None)
        if not callable(method):
            continue
        try:
            method(path)
            log(f"{method_name} OK: {path}", xbmc.LOGINFO)
            return True
        except Exception as exc:
            log(f"{method_name} failed: {exc}", xbmc.LOGWARNING)

    try:
        import json

        payload = json.dumps(
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "Player.AddSubtitle",
                "params": {"playerid": 1, "subtitle": path},
            }
        )
        xbmc.executeJSONRPC(payload)
        log(f"Player.AddSubtitle: {path}", xbmc.LOGINFO)
        return True
    except Exception as exc:
        log(f"Player.AddSubtitle failed: {exc}", xbmc.LOGERROR)
        return False


class AutoSubtitleWorker:
    """Run once per playback session."""

    _last_file: str = ""
    _busy: bool = False

    @classmethod
    def should_run(cls, playing_file: str) -> bool:
        if not playing_file or playing_file == cls._last_file:
            return False
        if cls._busy:
            return False
        return True

    @classmethod
    def run(cls) -> None:
        if not _auto_enabled():
            return

        info = get_playing_info()
        playing_file = info.get("playing_file") or ""
        if not playing_file or not xbmc.Player().isPlayingVideo():
            return
        if not cls.should_run(playing_file):
            return

        cls._busy = True
        cls._last_file = playing_file

        try:
            cls._process(info)
        finally:
            cls._busy = False

    @classmethod
    def _process(cls, info: dict) -> None:
        notify("YTS-Subs CZ", "Vyhledávám titulky…")

        profile = xbmcvfs.translatePath(__addon__.getAddonInfo("profile"))
        cache_dir = os.path.join(profile, "cache")
        temp_dir = xbmcvfs.translatePath("special://temp/yts_subs_cz/")
        if not xbmcvfs.exists(temp_dir):
            xbmcvfs.mkdirs(temp_dir)

        client = YtsSubsClient(logger=log)
        imdb_id, subs, info = resolve_imdb_and_subs(client, info, logger=log)
        log(f"auto attach {imdb_id}: {len(subs)} sub(s)", xbmc.LOGINFO)

        if not subs:
            notify(
                "YTS-Subs CZ",
                "České titulky nenalezeny na yts-subs.com",
                xbmcgui.NOTIFICATION_WARNING,
            )
            return

        best = _pick_best_subtitle(subs)
        if not best:
            notify("YTS-Subs CZ", "České titulky nenalezeny", xbmcgui.NOTIFICATION_WARNING)
            return

        path = client.download_subtitle(best.page_url, cache_dir)
        if not path or not os.path.isfile(path):
            notify(
                "YTS-Subs CZ",
                "Stažení titulků se nezdařilo",
                xbmcgui.NOTIFICATION_ERROR,
            )
            return

        dest = os.path.join(temp_dir, "auto_czech.srt")
        try:
            if xbmcvfs.exists(dest):
                xbmcvfs.delete(dest)
            xbmcvfs.copy(path, dest)
            final = dest
        except Exception:
            final = path

        time.sleep(0.5)
        if _apply_subtitle(final):
            notify("YTS-Subs CZ", "Nalezeny CZ titulky")
        else:
            notify(
                "YTS-Subs CZ",
                "Titulky staženy, ale Kodi je nepřipojilo automaticky",
                xbmcgui.NOTIFICATION_WARNING,
            )


class YtsPlaybackMonitor(xbmc.Monitor):
    """Background monitor for auto subtitle attach."""

    def __init__(self) -> None:
        super().__init__()
        self._pending = False

    def onAVStarted(self) -> None:
        if _auto_enabled():
            self._pending = True
            log("onAVStarted – scheduled auto subtitles", xbmc.LOGINFO)

    def onPlayBackStopped(self) -> None:
        AutoSubtitleWorker._last_file = ""
        self._pending = False

    def onPlayBackEnded(self) -> None:
        AutoSubtitleWorker._last_file = ""
        self._pending = False

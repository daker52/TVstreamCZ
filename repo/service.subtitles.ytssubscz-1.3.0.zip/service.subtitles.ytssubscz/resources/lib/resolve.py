# -*- coding: utf-8 -*-
"""Shared subtitle resolution: IMDB first, then YTS-Subs search."""
from __future__ import annotations

from typing import Callable, Optional

import xbmc

from .imdb_resolver import enrich_playback_info
from .yts_subs import YtsSubsClient, YtsSubtitle


def resolve_imdb_and_subs(
    client: YtsSubsClient,
    info: dict,
    logger: Optional[Callable[[str, int], None]] = None,
) -> tuple[str | None, list[YtsSubtitle], dict]:
    """
    Returns (imdb_id, czech_subtitles, enriched_info).
    """
    info = enrich_playback_info(info, logger=logger)

    imdb = str(info.get("imdb") or "").strip()
    if imdb and not imdb.startswith("tt"):
        imdb = f"tt{imdb}"

    if imdb:
        subs = client.list_czech_subtitles(imdb)
        if subs:
            return imdb, subs, info
        if logger:
            logger(f"IMDB {imdb}: 0 Czech subs on YTS", xbmc.LOGINFO)

    search_title = (
        info.get("search_title")
        or info.get("originaltitle")
        or info.get("title")
        or info.get("tvshowtitle")
        or ""
    )
    if not search_title:
        return imdb or None, [], info

    year = info.get("year") or None
    if year == 0:
        year = None

    title, parsed_year = client.normalize_filename_title(search_title)
    if not year and parsed_year:
        year = parsed_year

    if logger:
        logger(
            f"YTS search {title!r} year={year} (imdb was {imdb or 'none'})",
            xbmc.LOGINFO,
        )

    movies = client.search_movies(title, year)
    raw = str(info.get("title") or "")
    if not movies and raw and raw != title:
        movies = client.search_movies(client._clean_display_title(raw), year)

    best_imdb: str | None = imdb or None
    best_subs: list[YtsSubtitle] = []
    best_score = -1

    for movie in movies:
        subs = client.list_czech_subtitles(movie.imdb_id)
        if not subs:
            continue
        score = len(subs) * 10
        if year and movie.year == year:
            score += 100
        if score > best_score:
            best_score = score
            best_imdb = movie.imdb_id
            best_subs = subs

    return best_imdb, best_subs, info

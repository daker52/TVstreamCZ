# -*- coding: utf-8 -*-
"""Kodi subtitle module – stejný postup jako yts-subs.com: film → titulky."""
from __future__ import annotations

import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from .imdb_resolver import enrich_playback_info
from .playback_info import get_playing_info
from .yts_subs import YtsMovie, YtsSubsClient

__addon__ = xbmcaddon.Addon()
__addon_id__ = __addon__.getAddonInfo("id")
__handle__ = int(sys.argv[1])


def _log(msg: str, level: int = xbmc.LOGDEBUG) -> None:
    xbmc.log(f"[YTS-Subs CZ] {msg}", level)


def _params() -> dict:
    if len(sys.argv) > 2 and sys.argv[2].startswith("?"):
        return dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    return {}


def _plugin_url(**params: str) -> str:
    query = urllib.parse.urlencode({k: v for k, v in params.items() if v})
    return f"plugin://{__addon_id__}/?{query}"


def _get_playing_info() -> dict:
    return get_playing_info()


class YtsSubtitleDownloader:
    def __init__(self) -> None:
        self.params = _params()
        # TV / Android: přímý přístup na yts-subs.com (internet), bez PC a web2api
        self.client = YtsSubsClient(logger=_log)
        profile = xbmcvfs.translatePath(__addon__.getAddonInfo("profile"))
        self._cache_dir = os.path.join(profile, "cache")
        self._temp_dir = xbmcvfs.translatePath("special://temp/yts_subs_cz/")
        if not xbmcvfs.exists(self._temp_dir):
            xbmcvfs.mkdirs(self._temp_dir)

    def handle_action(self) -> None:
        action = self.params.get("action", "search")
        _log(f"action={action} params={self.params}", xbmc.LOGINFO)
        if action == "download":
            self.download()
        elif action == "list":
            self.list_subtitles()
        elif action == "manualsearch":
            query = self.params.get("searchstring", "")
            self.show_movies(query, source="manual")
        else:
            self.search()

    def search(self) -> None:
        """Automatické hledání: TMDB/IMDB pro český název, pak YTS-Subs."""
        info = enrich_playback_info(_get_playing_info(), logger=_log)
        _log(f"playing info: {info}", xbmc.LOGINFO)

        imdb = str(info.get("imdb") or "").strip()
        if imdb and not imdb.startswith("tt"):
            imdb = f"tt{imdb}"
        if imdb:
            self.params["imdb_id"] = imdb
            movie_title = (
                info.get("originaltitle")
                or info.get("title")
                or info.get("tvshowtitle")
                or ""
            )
            if movie_title:
                self.params["movie_title"] = movie_title
            self.list_subtitles()
            return

        search_title = (
            info.get("search_title")
            or info.get("originaltitle")
            or info.get("title")
            or info.get("tvshowtitle")
            or ""
        )
        year = info.get("year") or None
        if year == 0:
            year = None

        title, parsed_year = self.client.normalize_filename_title(search_title)
        if not year and parsed_year:
            year = parsed_year
        raw_czech = str(info.get("title") or "")
        alt_query = raw_czech if raw_czech and raw_czech != title else ""

        _log(
            f"search title {title!r} year={year} (resolved from {search_title!r})",
            xbmc.LOGINFO,
        )

        if not title:
            self._add_empty("Nepodařilo se zjistit název přehrávaného videa.")
            return

        self.show_movies(
            title,
            year=int(year) if year else None,
            source="auto",
            alt_query=alt_query,
        )

    def show_movies(
        self,
        query: str,
        year: int | None = None,
        source: str = "manual",
        alt_query: str = "",
    ) -> None:
        """Krok 1: seznam filmů z typeahead (/search/ajax/) jako na webu."""
        xbmcplugin.setPluginCategory(__handle__, "YTS-Subs – vyberte film")
        xbmcplugin.setContent(__handle__, "movies")

        clean_query = self.client._clean_display_title(query)
        if source == "manual" and len(clean_query) < 2:
            self._add_empty("Zadejte alespoň 2 znaky (jako na yts-subs.com).")
            return

        if source == "manual":
            movies = self.client.search_movies_typeahead(clean_query)
            if not movies:
                movies = self.client.search_movies_page(clean_query)
        else:
            movies = self.client.search_movies(clean_query, year)
            if not movies and alt_query:
                alt_clean = self.client._clean_display_title(alt_query)
                if alt_clean and alt_clean != clean_query:
                    _log(f"retry search with alt title {alt_clean!r}", xbmc.LOGINFO)
                    movies = self.client.search_movies(alt_clean, year)

        _log(f"{source} search {clean_query!r} -> {len(movies)} movie(s)", xbmc.LOGINFO)

        if not movies:
            self._add_empty(
                "Žádný film na yts-subs.com. Zkuste ruční hledání anglickým názvem "
                "(např. „The Matrix“, ne „Matice“)."
            )
            return

        enriched: list[tuple[YtsMovie, int]] = []
        for movie in movies:
            count = len(self.client.list_czech_subtitles(movie.imdb_id))
            enriched.append((movie, count))
            _log(f"  {movie.imdb_id} {movie.label}: {count} Czech sub(s)", xbmc.LOGINFO)

        enriched.sort(key=lambda item: (-item[1], -(item[0].year or 0)))
        for movie, count in enriched:
            self._add_movie_item(movie, czech_count=count)

    def _add_movie_item(self, movie: YtsMovie, czech_count: int = -1) -> None:
        if czech_count < 0:
            czech_count = len(self.client.list_czech_subtitles(movie.imdb_id))
        if czech_count == 0:
            label = f"{movie.label} [bez českých titulků na YTS-Subs]"
            label2 = "Zkuste jiný film ze seznamu"
        else:
            label = f"{movie.label} [{czech_count} českých verzí]"
            label2 = "České titulky"
        list_item = xbmcgui.ListItem(label=label, label2=label2)
        list_item.setArt({"icon": "DefaultMovies.png", "thumb": "DefaultMovies.png"})
        url = _plugin_url(
            action="list",
            imdb_id=movie.imdb_id,
            movie_title=movie.label,
        )
        xbmcplugin.addDirectoryItem(__handle__, url, list_item, isFolder=True)

    def list_subtitles(self) -> None:
        """Krok 2: po výběru filmu – české titulky z /movie-imdb/{imdb}."""
        imdb_id = (self.params.get("imdb_id") or "").strip()
        movie_title = urllib.parse.unquote_plus(self.params.get("movie_title", ""))
        if not imdb_id.startswith("tt"):
            self._add_empty("Chybí IMDB identifikátor filmu.")
            return

        category = movie_title or imdb_id
        xbmcplugin.setPluginCategory(__handle__, f"YTS-Subs – {category}")
        xbmcplugin.setContent(__handle__, "videos")

        subs = self.client.list_czech_subtitles(imdb_id)
        _log(f"{imdb_id} -> {len(subs)} Czech subtitle(s)", xbmc.LOGINFO)

        if not subs:
            self._add_empty(
                f"Film {imdb_id} nemá na yts-subs.com žádné české titulky. "
                "Zkuste jiný výsledek hledání nebo jiný zdroj titulků."
            )
            return

        for sub in subs:
            label = sub.release_name
            label2 = sub.uploader or "Čeština"
            if sub.rating:
                label = f"[{sub.rating}★] {label}"

            list_item = xbmcgui.ListItem(label=label, label2=label2)
            list_item.setProperty("sync", "false")
            page_enc = urllib.parse.quote(sub.page_url, safe="")
            url = _plugin_url(action="download", page_url=page_enc)
            xbmcplugin.addDirectoryItem(__handle__, url, list_item, isFolder=False)

    def download(self) -> None:
        page_url = urllib.parse.unquote(self.params.get("page_url", ""))
        if not page_url:
            xbmcgui.Dialog().ok("YTS-Subs CZ", "Chybí adresa titulků.")
            return

        progress = xbmcgui.DialogProgress()
        progress.create("YTS-Subs CZ", "Stahuji české titulky…")
        try:
            path = self.client.download_subtitle(page_url, self._cache_dir)
        finally:
            progress.close()

        if not path or not os.path.isfile(path):
            _log(f"download failed for {page_url}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok(
                "YTS-Subs CZ",
                "Stažení titulků se nezdařilo (web změnil formát nebo titulky nejsou dostupné).",
            )
            return

        lang = self.params.get("language", "cze") or "cze"
        dest = os.path.join(self._temp_dir, f"TempSubtitle.{lang}.srt")
        try:
            if xbmcvfs.exists(dest):
                xbmcvfs.delete(dest)
            xbmcvfs.copy(path, dest)
            final_path = dest
        except Exception:
            final_path = path

        list_item = xbmcgui.ListItem(label=final_path)
        xbmcplugin.addDirectoryItem(__handle__, final_path, list_item, isFolder=False)

    def _add_empty(self, message: str) -> None:
        item = xbmcgui.ListItem(label=f"[COLOR grey]{message}[/COLOR]")
        xbmcplugin.addDirectoryItem(__handle__, "", item, isFolder=False)


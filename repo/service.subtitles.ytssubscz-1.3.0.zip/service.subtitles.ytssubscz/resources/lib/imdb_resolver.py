# -*- coding: utf-8 -*-
"""Resolve Czech/local titles to IMDB + English search title (TMDB, aliases)."""
from __future__ import annotations

import re
from typing import Callable, Optional

import requests
import xbmc
import xbmcaddon

# České názvy filmů → anglický dotaz pro yts-subs / TMDB
_CZECH_MOVIE_ALIASES: dict[str, str] = {
    "uteč": "get out",
    "utec": "get out",
    "matice": "the matrix",
    "pán prstenů": "the lord of the rings",
    "pan prstenu": "the lord of the rings",
    "pán prstenů: společenstvo prstenu": "the fellowship of the ring",
    "temnota": "the dark knight",
    "začátek": "inception",
    "zacetek": "inception",
    "interstellar": "interstellar",
    "paraziti": "parasite",
    "parazit": "parasite",
    "neviditelný host": "the invisible guest",
    "neviditelny host": "the invisible guest",
}

_TVSTREAMCZ_ADDON_ID = "plugin.video.tvstreamcz"


def _normalize_key(value: str) -> str:
    value = (value or "").casefold().strip()
    for src, dst in (
        ("á", "a"), ("č", "c"), ("ď", "d"), ("é", "e"), ("ě", "e"),
        ("í", "i"), ("ň", "n"), ("ó", "o"), ("ř", "r"), ("š", "s"),
        ("ť", "t"), ("ú", "u"), ("ů", "u"), ("ý", "y"), ("ž", "z"),
    ):
        value = value.replace(src, dst)
    return re.sub(r"\s+", " ", value).strip()


def _looks_ascii_english(title: str) -> bool:
    """Heuristic: title is already usable for yts-subs without translation."""
    if not title:
        return False
    letters = [c for c in title if c.isalpha()]
    if not letters:
        return False
    ascii_ratio = sum(1 for c in letters if ord(c) < 128) / len(letters)
    return ascii_ratio > 0.92


class ImdbResolver:
    """Map title+year → imdb id + original English title."""

    def __init__(
        self,
        logger: Optional[Callable[[str, int], None]] = None,
        session: Optional[requests.Session] = None,
    ) -> None:
        self._session = session or requests.Session()
        self._session.headers.setdefault(
            "User-Agent",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        )
        self._logger = logger
        self._addon = xbmcaddon.Addon()
        self._cache: dict[tuple[str, Optional[int], str], Optional[dict]] = {}

    def _log(self, message: str, level: int = xbmc.LOGDEBUG) -> None:
        if self._logger:
            self._logger(message, level)

    def _tmdb_api_key(self) -> str:
        try:
            key = (self._addon.getSetting("tmdb_api_key") or "").strip()
            if key:
                return key
        except (AttributeError, RuntimeError):
            pass
        try:
            tv = xbmcaddon.Addon(_TVSTREAMCZ_ADDON_ID)
            key = (tv.getSetting("tmdb_api_key") or "").strip()
            if key:
                self._log("TMDB API key from TVStreamCZ", xbmc.LOGINFO)
                return key
        except Exception:
            pass
        return ""

    def _alias_search_title(self, title: str) -> Optional[str]:
        key = _normalize_key(title)
        return _CZECH_MOVIE_ALIASES.get(key)

    def _tmdb_request(
        self, path: str, params: Optional[dict] = None, language: str = "cs-CZ"
    ) -> Optional[dict]:
        api_key = self._tmdb_api_key()
        if not api_key:
            return None
        payload = {"api_key": api_key, "language": language, "include_adult": "false"}
        if params:
            payload.update(params)
        try:
            response = self._session.get(
                f"https://api.themoviedb.org/3/{path}",
                params=payload,
                timeout=12,
            )
            response.raise_for_status()
            return response.json()
        except (requests.RequestException, ValueError) as exc:
            self._log(f"TMDB {path} failed: {exc}", xbmc.LOGWARNING)
            return None

    def _tmdb_search(
        self, query: str, year: Optional[int], language: str
    ) -> Optional[dict]:
        params: dict = {"query": query}
        if year:
            params["year"] = year
        data = self._tmdb_request("search/movie", params, language=language)
        if not data or not data.get("results"):
            return None
        return data["results"][0]

    def _tmdb_movie_details(self, tmdb_id: int, language: str = "en-US") -> Optional[dict]:
        return self._tmdb_request(f"movie/{tmdb_id}", language=language)

    def _from_tmdb(self, title: str, year: Optional[int]) -> Optional[dict]:
        if not self._tmdb_api_key():
            return None

        queries = [title]
        alias = self._alias_search_title(title)
        if alias and alias not in queries:
            queries.append(alias)

        for lang in ("cs-CZ", "en-US"):
            for query in queries:
                hit = self._tmdb_search(query, year, language=lang)
                if not hit:
                    continue
                tmdb_id = hit.get("id")
                if not tmdb_id:
                    continue
                details = self._tmdb_movie_details(int(tmdb_id), language="en-US")
                if not details:
                    details = hit
                imdb_id = (details.get("imdb_id") or "").strip()
                original = (
                    details.get("original_title")
                    or hit.get("original_title")
                    or hit.get("title")
                    or ""
                ).strip()
                if not imdb_id and not original:
                    continue
                self._log(
                    f"TMDB '{query}' ({lang}) -> imdb={imdb_id} original={original!r}",
                    xbmc.LOGINFO,
                )
                return {
                    "imdb": imdb_id,
                    "originaltitle": original,
                    "search_title": original or alias or title,
                    "source": "tmdb",
                }
        return None

    def resolve(self, title: str, year: Optional[int] = None) -> Optional[dict]:
        """
        Return dict: imdb, originaltitle, search_title — or None.
        """
        title = (title or "").strip()
        if not title:
            return None
        if year == 0:
            year = None

        cache_key = (_normalize_key(title), year, "movie")
        if cache_key in self._cache:
            return self._cache[cache_key]

        result: Optional[dict] = None

        tmdb = self._from_tmdb(title, year)
        if tmdb:
            result = tmdb

        if not result:
            alias = self._alias_search_title(title)
            if alias:
                result = {
                    "imdb": "",
                    "originaltitle": alias.title(),
                    "search_title": alias,
                    "source": "alias",
                }
                self._log(f"alias '{title}' -> {alias!r}", xbmc.LOGINFO)

        if not result and _looks_ascii_english(title):
            result = {
                "imdb": "",
                "originaltitle": title,
                "search_title": title,
                "source": "ascii",
            }

        self._cache[cache_key] = result
        return result


def enrich_playback_info(info: dict, logger: Optional[Callable[[str, int], None]] = None) -> dict:
    """Fill imdb / originaltitle from TMDB when missing (e.g. Czech title Uteč)."""
    imdb = str(info.get("imdb") or "").strip()
    original = str(info.get("originaltitle") or "").strip()
    if imdb.startswith("tt") and original:
        return info

    title = original or str(info.get("title") or info.get("tvshowtitle") or "").strip()
    if not title:
        return info

    year = info.get("year") or None
    if year == 0:
        year = None

    resolved = ImdbResolver(logger=logger).resolve(title, int(year) if year else None)
    if not resolved:
        return info

    out = dict(info)
    if resolved.get("imdb") and not imdb:
        out["imdb"] = resolved["imdb"]
    if resolved.get("originaltitle") and not original:
        out["originaltitle"] = resolved["originaltitle"]
    if resolved.get("search_title"):
        out["search_title"] = resolved["search_title"]
    return out

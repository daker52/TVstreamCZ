"""Czech subtitle lookup and download from yts-subs.com."""
from __future__ import annotations

import base64
import io
import os
import re
import zipfile
from dataclasses import dataclass
from typing import Callable, List, Optional
from urllib.parse import quote

import requests

_BASE_URL = "https://yts-subs.com"
_CZECH_ROW = re.compile(
    r"<tr[^>]*>.*?<span class=\"sub-lang\">Czech</span>.*?"
    r"href=[\"'](/subtitles/[^\"']+)[\"'].*?"
    r"<span class=\"text-muted\">subtitle</span>\s*([^<]+)</a>.*?"
    r"class=\"uploader-cell\">([^<]*)</td>",
    re.IGNORECASE | re.DOTALL,
)
_RATING_IN_ROW = re.compile(
    r"<td class=\"rating-cell\">\s*<span[^>]*>(\d+)</span>",
    re.IGNORECASE,
)
_DATA_LINK = re.compile(
    r'id="btn-download-subtitle"[^>]+data-link="([^"]+)"',
    re.IGNORECASE,
)


@dataclass(frozen=True)
class YtsMovie:
    imdb_id: str
    title: str
    year: Optional[int]
    display_name: str = ""

    @property
    def label(self) -> str:
        if self.display_name:
            return self.display_name
        if self.year:
            return f"{self.title} ({self.year})"
        return self.title


@dataclass(frozen=True)
class YtsSubtitle:
    release_name: str
    rating: int
    page_url: str
    uploader: str = ""


class YtsSubsClient:
    """Fetch Czech subtitles from yts-subs.com (works from Kodi on TV over internet)."""

    def __init__(
        self,
        logger: Optional[Callable[[str, int], None]] = None,
        session: Optional[requests.Session] = None,
    ) -> None:
        self._session = session or requests.Session()
        self._session.headers.setdefault(
            "User-Agent",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        )
        self._logger = logger

    def _log(self, message: str, level: int = 0) -> None:
        if self._logger:
            self._logger(message, level)

    def search_movies_typeahead(self, query: str) -> List[YtsMovie]:
        """Same API as web typeahead: GET /search/ajax/{q}."""
        query = (query or "").strip()
        if len(query) < 2:
            return []
        try:
            response = self._session.get(
                f"{_BASE_URL}/search/ajax/{quote(query)}",
                timeout=15,
                headers={"X-Requested-With": "XMLHttpRequest"},
            )
            response.raise_for_status()
            results = response.json()
        except (requests.RequestException, ValueError) as exc:
            self._log(f"YTS-Subs typeahead failed for '{query}': {exc}")
            return []
        if not isinstance(results, list):
            return []
        return self._parse_typeahead_results(results)

    def search_movies_page(self, query: str) -> List[YtsMovie]:
        """Fallback: full-text search page /search/{q} (form submit on web)."""
        query = (query or "").strip()
        if len(query) < 2:
            return []
        try:
            response = self._session.get(
                f"{_BASE_URL}/search/{quote(query)}",
                timeout=20,
            )
            response.raise_for_status()
            html = response.text
        except requests.RequestException as exc:
            self._log(f"YTS-Subs search page failed for '{query}': {exc}")
            return []

        movies: List[YtsMovie] = []
        seen: set[str] = set()
        for imdb_id, title, year in re.findall(
            r'href="/movie-imdb/(tt\d+)"[^>]*>.*?<h4[^>]*>([^<]+)</h4>.*?(\d{4})',
            html,
            re.IGNORECASE | re.DOTALL,
        ):
            if imdb_id in seen:
                continue
            seen.add(imdb_id)
            try:
                movie_year = int(year)
            except ValueError:
                movie_year = None
            movies.append(
                YtsMovie(
                    imdb_id=imdb_id,
                    title=title.strip(),
                    year=movie_year,
                    display_name=f"{title.strip()} ({year})",
                )
            )

        if not movies:
            for imdb_id in dict.fromkeys(
                re.findall(r"/movie-imdb/(tt\d+)", html, re.IGNORECASE)
            ):
                if imdb_id in seen:
                    continue
                seen.add(imdb_id)
                movies.append(YtsMovie(imdb_id=imdb_id, title=imdb_id, year=None))

        return movies

    def search_movies(self, title: str, year: Optional[int] = None) -> List[YtsMovie]:
        """Collect movies like the web UI: typeahead first, then /search/ page."""
        merged: dict[str, YtsMovie] = {}
        for query in self.expand_search_queries(title, year):
            for movie in self.search_movies_typeahead(query):
                merged.setdefault(movie.imdb_id, movie)
            if len(merged) >= 15:
                break

        if not merged:
            for query in self.expand_search_queries(title, year):
                for movie in self.search_movies_page(query):
                    merged.setdefault(movie.imdb_id, movie)
                if len(merged) >= 15:
                    break

        movies = list(merged.values())
        movies.sort(key=lambda item: (-(item.year or 0), item.label.lower()))
        self._log(f"YTS-Subs search '{title}' -> {len(movies)} movie(s)")
        return movies

    def find_movie(self, title: str, year: Optional[int] = None) -> Optional[YtsMovie]:
        movies = self.search_movies(title, year)
        if not movies:
            return None
        if len(movies) == 1:
            return movies[0]
        return self._pick_best_movie(movies, title, year)

    def _pick_best_movie(
        self, movies: List[YtsMovie], title: str, year: Optional[int] = None
    ) -> Optional[YtsMovie]:
        clean = self._clean_display_title(title)
        year = year or self._extract_year(clean)
        normalized_query = self._normalize(clean)
        best: Optional[tuple[int, YtsMovie]] = None
        for movie in movies:
            score = 0
            normalized_title = self._normalize(movie.title)
            if normalized_query == normalized_title:
                score += 80
            elif normalized_query in normalized_title or normalized_title in normalized_query:
                score += 45
            if year and movie.year:
                if year == movie.year:
                    score += 60
                elif abs(year - movie.year) <= 1:
                    score += 20
            elif year is None and movie.year and movie.year >= 2020:
                score += movie.year - 2019
            if best is None or score > best[0]:
                best = (score, movie)
        return best[1] if best else movies[0]

    @staticmethod
    def _parse_typeahead_results(results: list) -> List[YtsMovie]:
        movies: List[YtsMovie] = []
        for entry in results:
            imdb_id = str(entry.get("mov_imdb_code") or "").strip()
            movie_title = str(entry.get("mov_title") or "").strip()
            if not imdb_id or not movie_title:
                continue
            try:
                movie_year = int(entry.get("mov_year") or 0) or None
            except (TypeError, ValueError):
                movie_year = None
            display_name = str(entry.get("titleWithYear") or "").strip()
            movies.append(
                YtsMovie(
                    imdb_id=imdb_id,
                    title=movie_title,
                    year=movie_year,
                    display_name=display_name,
                )
            )
        return movies

    def expand_search_queries(self, title: str, year: Optional[int] = None) -> List[str]:
        """Build ordered search queries (cleaned title, aliases, shorter variants)."""
        clean = self._clean_display_title(title)
        year = year or self._extract_year(clean)
        queries: List[str] = []
        seen: set[str] = set()

        def add(query: str) -> None:
            query = re.sub(r"\s+", " ", (query or "").strip())
            if not query:
                return
            key = query.casefold()
            if key in seen:
                return
            seen.add(key)
            queries.append(query)

        norm = self._normalize(clean)
        sequel_hint = any(token in norm for token in ("2", "zacina", "hra")) or re.search(
            r"\b2\b", clean, re.IGNORECASE
        )
        if "nevesta" in norm:
            if sequel_hint:
                add("here i come")
            add("ready or not")
        if "readyornot" in norm and sequel_hint:
            add("here i come")
            add("ready or not")
        if sequel_hint and "ready" in norm and "not" in norm:
            add("here i come")

        add(clean)
        words = clean.split()
        while len(words) > 2:
            words = words[:-1]
            add(" ".join(words))

        if year:
            add(re.sub(r"\b(19|20)\d{2}\b", "", clean).strip())

        return queries

    def list_czech_subtitles(self, imdb_id: str) -> List[YtsSubtitle]:
        imdb_id = (imdb_id or "").strip()
        if not imdb_id.startswith("tt"):
            return []
        try:
            response = self._session.get(
                f"{_BASE_URL}/movie-imdb/{imdb_id}",
                timeout=20,
            )
            response.raise_for_status()
            html = response.text
        except requests.RequestException as exc:
            self._log(f"YTS-Subs movie page failed: {exc}")
            return []

        subtitles: List[YtsSubtitle] = []
        seen_urls: set[str] = set()
        for match in _CZECH_ROW.finditer(html):
            row_html = match.group(0)
            path = match.group(1)
            release_name = match.group(2).strip()
            uploader = match.group(3).strip()
            page_url = f"{_BASE_URL}{path}" if path.startswith("/") else path
            if page_url in seen_urls:
                continue
            seen_urls.add(page_url)
            rating_match = _RATING_IN_ROW.search(row_html)
            rating = int(rating_match.group(1)) if rating_match else 0
            subtitles.append(
                YtsSubtitle(
                    release_name=release_name,
                    rating=rating,
                    page_url=page_url,
                    uploader=uploader,
                )
            )

        if not subtitles:
            for path in dict.fromkeys(
                re.findall(r'href=["\'](/subtitles/[^"\']*-czech[^"\']*)["\']', html, re.IGNORECASE)
            ):
                page_url = f"{_BASE_URL}{path}"
                if page_url in seen_urls:
                    continue
                seen_urls.add(page_url)
                slug = path.rsplit("/", 1)[-1]
                release_name = slug.replace("-czech-yify-", " ").replace("-", " ")
                subtitles.append(
                    YtsSubtitle(release_name=release_name, rating=0, page_url=page_url)
                )

        subtitles.sort(key=lambda item: (-item.rating, item.release_name.lower()))
        return subtitles

    def download_subtitle(self, page_url: str, cache_dir: str) -> Optional[str]:
        page_url = (page_url or "").strip()
        if not page_url:
            return None
        try:
            response = self._session.get(page_url, timeout=20)
            response.raise_for_status()
        except requests.RequestException as exc:
            self._log(f"YTS-Subs subtitle page failed: {exc}")
            return None

        link_match = _DATA_LINK.search(response.text)
        if not link_match:
            alt = re.search(r'data-link="([^"]+)"', response.text, re.I)
            link_match = alt
        if not link_match:
            self._log(f"YTS-Subs download link not found: {page_url}")
            return None

        try:
            zip_url = base64.b64decode(link_match.group(1)).decode("utf-8")
        except (ValueError, UnicodeDecodeError) as exc:
            self._log(f"YTS-Subs invalid download link: {exc}")
            return None

        try:
            zip_response = self._session.get(zip_url, timeout=45)
            zip_response.raise_for_status()
        except requests.RequestException as exc:
            self._log(f"YTS-Subs zip download failed: {exc}")
            return None

        os.makedirs(cache_dir, exist_ok=True)
        slug = page_url.rstrip("/").rsplit("/", 1)[-1]
        try:
            with zipfile.ZipFile(io.BytesIO(zip_response.content)) as archive:
                srt_names = [
                    name
                    for name in archive.namelist()
                    if name.lower().endswith(".srt") and not name.endswith("/")
                ]
                if not srt_names:
                    self._log("YTS-Subs zip contains no .srt file")
                    return None
                srt_name = srt_names[0]
                target_path = os.path.join(cache_dir, f"{slug}.srt")
                with archive.open(srt_name) as source, open(target_path, "wb") as target:
                    target.write(source.read())
                return target_path
        except (zipfile.BadZipFile, OSError) as exc:
            self._log(f"YTS-Subs extract failed: {exc}")
            return None

    @staticmethod
    def _normalize(value: str) -> str:
        value = value.casefold()
        for src, dst in (
            ("á", "a"), ("č", "c"), ("ď", "d"), ("é", "e"), ("ě", "e"),
            ("í", "i"), ("ň", "n"), ("ó", "o"), ("ř", "r"), ("š", "s"),
            ("ť", "t"), ("ú", "u"), ("ů", "u"), ("ý", "y"), ("ž", "z"),
        ):
            value = value.replace(src, dst)
        return re.sub(r"[^a-z0-9]+", "", value)

    def normalize_filename_title(self, raw: str) -> tuple[str, Optional[int]]:
        """
        Převod názvu souboru na hledatelný titul (např. A.p.e.x.2026.mkv -> Apex, 2026).
        """
        clean = (raw or "").strip()
        year = self._extract_year(clean)
        clean = re.sub(r"\.(mkv|mp4|avi|m4v|wmv|mov)$", "", clean, flags=re.IGNORECASE)
        tokens = [t for t in re.split(r"[.\s_]+", clean) if t]
        if not tokens:
            return raw, year

        letter_parts: list[str] = []
        for token in tokens:
            if re.fullmatch(r"\d{4}", token):
                if not year:
                    year = int(token)
                continue
            if len(token) == 1 and token.isalpha():
                letter_parts.append(token)
            else:
                letter_parts = []
                break

        if len(letter_parts) >= 2:
            word = "".join(letter_parts)
            if word.isalpha():
                return word.capitalize(), year

        name = re.sub(r"\b(19|20)\d{2}\b", "", clean).strip(" .-_")
        name = re.sub(r"[.\s_]+", " ", name).strip()
        return name or raw, year

    @staticmethod
    def _clean_display_title(title: str) -> str:
        clean = (title or "").strip()
        clean = re.sub(r"\.(mkv|mp4|avi|m4v|wmv|mov)$", "", clean, flags=re.IGNORECASE)
        clean = re.sub(
            r"\b(cz\s*titulky|titulky|cz\s*dabing|dabing|web[- ]?dl|bluray|bdrip|brrip)\b",
            "",
            clean,
            flags=re.IGNORECASE,
        )
        clean = re.sub(r"\s+", " ", clean).strip(" -._")
        return clean

    @staticmethod
    def _extract_year(title: str) -> Optional[int]:
        match = re.search(r"\b(19|20)\d{2}\b", title or "")
        if not match:
            return None
        try:
            return int(match.group(0))
        except ValueError:
            return None

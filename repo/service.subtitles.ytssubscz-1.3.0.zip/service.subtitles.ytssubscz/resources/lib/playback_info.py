# -*- coding: utf-8 -*-
"""Shared helpers for reading currently playing video metadata."""
from __future__ import annotations

import os
import urllib.parse

import xbmc
import xbmcgui


def log(msg: str, level: int = xbmc.LOGDEBUG) -> None:
    xbmc.log(f"[YTS-Subs CZ] {msg}", level)


def notify(title: str, message: str, icon: int = xbmcgui.NOTIFICATION_INFO) -> None:
    try:
        xbmcgui.Dialog().notification(title, message, icon=icon, time=4000)
    except TypeError:
        xbmcgui.Dialog().notification(title, message, time=4000)


def get_playing_info() -> dict:
    """Read metadata from the currently playing video."""
    info: dict = {}
    player = xbmc.Player()
    if not player.isPlayingVideo():
        return info
    try:
        tag = player.getVideoInfoTag()
        info["title"] = tag.getTitle() or ""
        info["originaltitle"] = tag.getOriginalTitle() or ""
        info["year"] = tag.getYear() or 0
        info["imdb"] = tag.getIMDBNumber() or ""
        info["tvshowtitle"] = tag.getTVShowTitle() or ""
        info["season"] = tag.getSeason() or 0
        info["episode"] = tag.getEpisode() or 0
    except RuntimeError as exc:
        log(f"VideoInfoTag error: {exc}", xbmc.LOGWARNING)

    try:
        playing_file = player.getPlayingFile() or ""
    except RuntimeError:
        playing_file = ""

    info["playing_file"] = playing_file

    if playing_file.startswith("plugin://"):
        parsed = urllib.parse.urlparse(playing_file)
        plugin_params = dict(urllib.parse.parse_qsl(parsed.query))
        movie_title = urllib.parse.unquote_plus(
            plugin_params.get("movie_title") or plugin_params.get("search_title") or ""
        )
        file_title = urllib.parse.unquote_plus(plugin_params.get("title") or "")
        if movie_title:
            info["title"] = movie_title
            info["originaltitle"] = movie_title
        elif file_title and not info.get("title"):
            info["title"] = file_title
        if plugin_params.get("year"):
            try:
                info["year"] = int(plugin_params["year"])
            except ValueError:
                pass
        if plugin_params.get("imdb") and not info.get("imdb"):
            info["imdb"] = plugin_params["imdb"]
        if plugin_params.get("originaltitle") and not info.get("originaltitle"):
            info["originaltitle"] = urllib.parse.unquote_plus(
                plugin_params["originaltitle"]
            )
    elif playing_file and not info.get("title"):
        info["title"] = os.path.basename(playing_file)

    return info

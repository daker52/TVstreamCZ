# YTS-Subs CZ

Doplněk pro **Kodi** — české titulky k filmům a seriálům. Funguje **zdarma**, bez registrace. Stačí internet.

## Co umí

- **Automaticky** při startu filmu: vyhledání a zapnutí českých titulků
- **Ručně:** Titulky → Stáhnout → YTS-Subs CZ
- Rozpoznání českého názvu filmu a převod na správný anglický / IMDB záznam (volitelný TMDB klíč)
- Funguje na TV, PC i Android Kodi — nepotřebuje PC na pozadí

## Instalace

1. Stáhněte nebo naklonujte repozitář.
2. Složku `service.subtitles.ytssubscz` zkopírujte do složky doplňků Kodi:
   - **Windows:** `%APPDATA%\Kodi\addons\`
   - **Linux:** `~/.kodi/addons/`
3. Restart Kodi.
4. *Doplňky → Moje doplňky* — ověřte, že je **YTS-Subs CZ** aktivní.

### Závislosti

- Kodi 20+ (Python 3)
- `script.module.requests`

## Nastavení

*Doplňky → YTS-Subs CZ → Nastavení*

- **Automatické titulky** — zapnuto/vypnuto (výchozí: zapnuto)
- **TMDB API klíč** — volitelné; prázdné = použije klíč z TVStreamCZ, pokud je nastaven

## Licence

GPL-2.0-or-later

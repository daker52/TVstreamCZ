# -*- coding: utf-8 -*-
"""Entry point for Kodi subtitle module (xbmc.subtitle.module)."""
import sys

import xbmcplugin

from resources.lib.yts_subtitle_downloader import YtsSubtitleDownloader

if __name__ == "__main__":
    YtsSubtitleDownloader().handle_action()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
